// components/members/index.jsx
import React, { useState, useEffect } from 'react';
import { PlusCircle } from 'lucide-react';
import MembersList from './MembersList';
import MemberForm from './MemberForm';
import SearchBar from './SearchBar';
import { fetchMembers, addMember, updateMember, deleteMember } from './membersAPI';

const Members = () => {
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentMember, setCurrentMember] = useState({
    first_name: '',
    last_name: '',
    gender: '',
    date_of_birth: '',
    phone: '',
    alt_phone: '',
    email: '',
    address: '',
    medical_info: '',
    join_date: '',
    status: '1'
  });

  // Fetch members when component mounts
  useEffect(() => {
    const loadMembers = async () => {
      try {
        setLoading(true);
        const data = await fetchMembers();
        setMembers(data);
        setError(null);
      } catch (err) {
        setError('Error loading members: ' + err.message);
        console.error('Error fetching members:', err);
      } finally {
        setLoading(false);
      }
    };

    loadMembers();
  }, []);

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, type, files, value } = e.target;
  
    setCurrentMember(prevState => ({
      ...prevState,
      [name]: type === 'file' ? files[0] : value
    }));
  };

  // Reset form fields
  const resetForm = () => {
    setCurrentMember({
      first_name: '',
      last_name: '',
      gender: '',
      date_of_birth: '',
      phone: '',
      alt_phone: '',
      email: '',
      address: '',
      medical_info: '',
      join_date: '',
      status: '1'
    });
  };

  // Handle add member submission
  const handleAddMember = async (e) => {
    e.preventDefault();
  
    try {
      const result = await addMember(currentMember);
      
      if (result.status && result.member) {
        setMembers(prevMembers => [...prevMembers, result.member]);
        resetForm();
        setShowAddForm(false);
      } else if (result.errors) {
        setError('Validation error: ' + result.errors);
      } else {
        setError('Something went wrong while adding member.');
      }
    } catch (err) {
      setError('Error adding member: ' + err.message);
      console.error('Error adding member:', err);
    }
  };

  // Handle edit member submission
  const handleUpdateMember = async (e) => {
    e.preventDefault();
  
    try {
      const result = await updateMember(currentMember);
      
      if (result.status && result.member) {
        setMembers(prevMembers =>
          prevMembers.map(member => member.id === result.member.id ? result.member : member)
        );
        resetForm();
        setShowEditForm(false);
      } else {
        throw new Error(result.message || 'Failed to update member');
      }
    } catch (err) {
      setError('Error updating member: ' + err.message);
      console.error('Error updating member:', err);
    }
  };

  // Edit member
  const editMember = (member) => {
    setCurrentMember({...member});
    setShowEditForm(true);
    setShowAddForm(false);
  };

  // Handle delete member
  const handleDeleteMember = async (id) => {
    if (window.confirm('Are you sure you want to delete this member?')) {
      try {
        const result = await deleteMember(id);
        
        if (result.status) {
          setMembers(prevMembers => prevMembers.filter(member => member.id !== id));
        } else {
          throw new Error(result.message || 'Failed to delete member');
        }
      } catch (err) {
        setError('Error deleting member: ' + err.message);
        console.error('Error deleting member:', err);
      }
    }
  };

  // Filter members based on search term
  const filteredMembers = members.filter(member => 
    `${member.first_name} ${member.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.phone?.includes(searchTerm)
  );

  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="h3 mb-0">Members</h2>
        <button 
          className="btn btn-primary" 
          onClick={() => {
            setShowAddForm(true);
            setShowEditForm(false);
            resetForm();
          }}
        >
          <PlusCircle size={18} className="me-1" />
          Add New Member
        </button>
      </div>

      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
          <button 
            type="button" 
            className="btn-close float-end" 
            aria-label="Close" 
            onClick={() => setError(null)}
          ></button>
        </div>
      )}

      {/* Member Forms */}
      {showAddForm && (
        <MemberForm 
          isEdit={false}
          currentMember={currentMember}
          handleInputChange={handleInputChange}
          onSubmit={handleAddMember}
          onClose={() => setShowAddForm(false)}
        />
      )}
      
      {showEditForm && (
        <MemberForm 
          isEdit={true}
          currentMember={currentMember}
          handleInputChange={handleInputChange}
          onSubmit={handleUpdateMember}
          onClose={() => setShowEditForm(false)}
        />
      )}

      <div className="card shadow">
        <div className="card-header bg-light">
          <div className="row align-items-center">
            <div className="col">
              <h5 className="mb-0">All Members</h5>
            </div>
            <div className="col-md-4">
              <SearchBar 
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
              />
            </div>
          </div>
        </div>
        
        <MembersList 
          loading={loading}
          members={filteredMembers}
          totalMembers={members.length}
          editMember={editMember}
          deleteMember={handleDeleteMember}
        />
      </div>
    </div>
  );
};

export default Members;